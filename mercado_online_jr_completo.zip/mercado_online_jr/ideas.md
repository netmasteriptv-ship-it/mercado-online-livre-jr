# Brainstorming de Design - Mercado Online Livre Jr

## Contexto
Site de e-commerce premium focado em perfumes árabes, ferramentas e shampoos. Necessita transmitir elegância, confiabilidade e sofisticação, com interface responsiva e intuitiva.

---

<response>
<probability>0.08</probability>
<text>

## Abordagem 1: Luxo Minimalista com Tipografia Serif

**Design Movement:** Modernismo Luxuoso (inspirado em boutiques de alta moda)

**Core Principles:**
- Espaço em branco generoso como elemento de design
- Tipografia serif elegante para títulos, sans-serif limpo para corpo
- Paleta restrita: ouro, preto profundo, branco e tons neutros
- Foco absoluto no produto, sem distrações visuais

**Color Philosophy:**
- Fundo: Branco puro (elegância e clareza)
- Destaque: Ouro 24k (#d4af37) - luxo, exclusividade
- Texto: Preto profundo (#1a1a1a) - legibilidade e sofisticação
- Acentos: Cinza claro (#f5f5f5) para separação sutil

**Layout Paradigm:**
- Assimétrico com ênfase vertical
- Seções com espaçamento amplo (80-120px entre blocos)
- Cards de produtos em grid 3 colunas, com muito ar ao redor
- Hero section com imagem de fundo escura e texto branco sobreposto

**Signature Elements:**
- Linhas horizontais finas em ouro separando seções
- Ícones minimalistas em ouro para CTAs
- Bordas sutis em ouro ao redor de cards premium

**Interaction Philosophy:**
- Hover: Elevação suave com sombra, sem mudança de cor
- Transições lentas e elegantes (0.4s)
- Feedback visual discreto mas perceptível

**Animation:**
- Fade-in ao scroll (opacity 0 → 1)
- Slide suave de baixo para cima em cards
- Hover em botões: escala 1 → 1.05 com sombra aumentada
- Transição de cor em links: 0.3s ease-in-out

**Typography System:**
- Títulos: Playfair Display 700 (serif elegante)
- Subtítulos: Playfair Display 400
- Corpo: Open Sans 400 (legível, moderno)
- Ênfase: Open Sans 600 (sem serifa, peso médio)

</text>
</response>

---

<response>
<probability>0.07</probability>
<text>

## Abordagem 2: Artesanal Contemporâneo com Texturas

**Design Movement:** Artesanato Digital (inspirado em design de packaging premium)

**Core Principles:**
- Texturas sutis (papel, linho) como fundo
- Paleta terrosa com acentos em tons quentes
- Tipografia mista: script elegante + sans-serif moderno
- Sensação de handmade mas profissional

**Color Philosophy:**
- Fundo: Bege natural (#faf8f3) - caloroso, acessível
- Primário: Marrom chocolate (#5c4a3d) - profundidade, confiança
- Acentos: Terracota (#c85a3a) - energia, vitalidade
- Secundário: Creme (#f0ebe5) - suavidade

**Layout Paradigm:**
- Diagonal e assimétrico com elementos sobrepostos
- Seções com backgrounds coloridos alternados
- Cards com cantos levemente arredondados (8px)
- Imagens com molduras sutis ou efeito polaroid

**Signature Elements:**
- Padrão de linho ou papel como textura de fundo
- Ícones desenhados à mão (stroke style)
- Divisores em forma de ondas ou linhas orgânicas

**Interaction Philosophy:**
- Hover: Mudança sutil de cor + rotação leve (2-3°)
- Feedback tátil visual (como tocar papel)
- Transições naturais e fluidas

**Animation:**
- Parallax suave no scroll
- Rotate 0 → 3° em hover
- Pulse suave em CTAs
- Fade com delay em cascata para elementos

**Typography System:**
- Títulos: Playfair Display 700 (serif)
- Destaque: Caveat ou Dancing Script (script elegante)
- Corpo: Poppins 400 (moderno, amigável)
- Ênfase: Poppins 600

</text>
</response>

---

<response>
<probability>0.09</probability>
<text>

## Abordagem 3: Moderno Dinâmico com Gradientes Sutis

**Design Movement:** Neomorfismo Contemporâneo (design moderno com profundidade)

**Core Principles:**
- Gradientes sutis para profundidade
- Tipografia bold e moderna
- Cores vibrantes mas equilibradas
- Movimento e dinamismo em cada interação

**Color Philosophy:**
- Fundo: Branco com gradiente sutil (#ffffff → #f8f9ff)
- Primário: Azul profundo (#2c3e50) - confiança, modernidade
- Acentos: Coral/Salmão (#ff6b6b) - energia, ação
- Secundário: Verde menta (#26d0ce) - frescor

**Layout Paradigm:**
- Grid moderno com cards flutuantes
- Seções com altura variável para ritmo visual
- Elementos sobrepostos com sombras profundas
- Hero com video ou imagem dinâmica

**Signature Elements:**
- Sombras soft (blur 20-30px) para efeito flutuante
- Gradientes em botões e cards
- Ícones modernos e coloridos
- Bordas com gradiente em cards premium

**Interaction Philosophy:**
- Hover: Elevação com sombra aumentada + mudança de gradiente
- Cliques com feedback visual imediato
- Transições rápidas e responsivas

**Animation:**
- Bounce suave em botões
- Slide e fade combinados
- Glow effect em hover
- Loader animado em CTAs

**Typography System:**
- Títulos: Montserrat 700 (moderno, bold)
- Subtítulos: Montserrat 500
- Corpo: Inter 400 (limpo, legível)
- Ênfase: Inter 600

</text>
</response>

---

## Decisão Final

**Escolhido: Abordagem 1 - Luxo Minimalista com Tipografia Serif**

Esta abordagem é a mais apropriada para o **Mercado Online Livre Jr** porque:

1. **Alinha com o conteúdo:** Perfumes árabes, ferramentas premium e shampoos exigem uma apresentação sofisticada
2. **Tipografia serif elegante:** Playfair Display transmite luxo e exclusividade, essencial para e-commerce premium
3. **Paleta ouro/preto:** Já mencionada no arquivo original, reforça identidade visual
4. **Espaço em branco:** Permite que cada produto seja o foco, sem competição visual
5. **Fácil manutenção:** Design limpo facilita atualizações e adições futuras

### Implementação:
- Tipografia: Playfair Display 700 (títulos) + Open Sans (corpo)
- Cores: Ouro (#d4af37), Preto (#1a1a1a), Branco (#ffffff), Cinza (#f5f5f5)
- Espaçamento: Amplo (80-120px entre seções)
- Animações: Fade-in ao scroll, hover suave com elevação
- Layout: Assimétrico com ênfase vertical, cards em grid 3 colunas
