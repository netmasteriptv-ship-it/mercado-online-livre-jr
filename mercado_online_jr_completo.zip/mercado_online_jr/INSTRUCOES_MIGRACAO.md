# Instruções de Migração - Mercado Online Livre Jr

## 📋 Informações do Projeto

**Nome:** Mercado Online Livre Jr
**Tipo:** Site Estático com React 19 + Tailwind CSS 4
**Tecnologias:** React, TypeScript, Tailwind CSS, Vite, Wouter

---

## 🚀 Como Fazer Deploy em Sua Própria Hospedagem

### Pré-requisitos
- Node.js 18+ instalado
- npm ou pnpm instalado
- Acesso à sua hospedagem (Vercel, Netlify, GitHub Pages, etc.)

### Passo 1: Clonar o Repositório
```bash
git clone <seu-repositorio-url>
cd mercado_online_jr
```

### Passo 2: Instalar Dependências
```bash
pnpm install
# ou
npm install
```

### Passo 3: Compilar o Projeto
```bash
pnpm build
# ou
npm run build
```

Isso criará a pasta `dist/` com os arquivos prontos para produção.

### Passo 4: Deploy em Diferentes Plataformas

#### **Vercel (Recomendado)**
1. Acesse https://vercel.com
2. Clique em "New Project"
3. Selecione seu repositório GitHub
4. Vercel detectará automaticamente que é um projeto Vite
5. Clique em "Deploy"

#### **Netlify**
1. Acesse https://netlify.com
2. Clique em "New site from Git"
3. Selecione seu repositório
4. Configure:
   - Build command: `pnpm build`
   - Publish directory: `dist`
5. Clique em "Deploy site"

#### **GitHub Pages**
1. Edite o arquivo `vite.config.ts` e adicione:
```javascript
export default {
  base: '/mercado_online_jr/', // seu-repositorio-name
  // ... resto da config
}
```

2. Execute:
```bash
pnpm build
git add dist/
git commit -m "Deploy"
git push
```

3. Nas configurações do repositório GitHub:
   - Vá para Settings > Pages
   - Source: Deploy from a branch
   - Branch: main, folder: /root

#### **Hospedagem Compartilhada (cPanel, Plesk, etc.)**
1. Compile o projeto: `pnpm build`
2. Faça upload da pasta `dist/` para o diretório public_html via FTP
3. Certifique-se de que o servidor está configurado para servir arquivos estáticos

---

## 🔧 Configurações Importantes

### Variáveis de Ambiente
Crie um arquivo `.env` na raiz do projeto (se necessário):
```
VITE_APP_TITLE=Mercado Online Livre Jr
VITE_APP_LOGO=/logo.png
```

### Customizações Recomendadas

#### 1. **Alterar Número do WhatsApp**
Edite `client/src/pages/Home.tsx` e procure por:
```javascript
const WHATSAPP_NUMBER = "5511916745566"; // Altere para seu número
```

#### 2. **Alterar Cores**
Edite `client/src/index.css` e modifique as variáveis CSS:
```css
--primary: #d4af37; /* Cor primária */
--secondary: #1a1a1a; /* Cor secundária */
```

#### 3. **Adicionar Mais Produtos**
Edite `client/src/pages/Home.tsx` e adicione produtos ao array:
```javascript
const products: Product[] = [
  {
    id: 5,
    name: "Novo Produto",
    category: "Categoria",
    image: "/images/novo-produto.jpg",
    link: "https://seu-link-aqui",
  },
  // ... mais produtos
];
```

#### 4. **Customizar Depoimentos**
Edite `client/src/pages/Home.tsx` e modifique o array de depoimentos:
```javascript
const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Nome do Cliente",
    text: "Depoimento aqui...",
    rating: 5,
  },
  // ... mais depoimentos
];
```

---

## 📁 Estrutura do Projeto

```
mercado_online_jr/
├── client/
│   ├── public/
│   │   └── images/          # Imagens do site
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Home.tsx     # Página principal
│   │   │   ├── Privacidade.tsx
│   │   │   ├── Termos.tsx
│   │   │   └── NotFound.tsx
│   │   ├── components/      # Componentes reutilizáveis
│   │   ├── App.tsx          # Rotas principais
│   │   ├── index.css        # Estilos globais
│   │   └── main.tsx         # Entry point
│   └── index.html
├── package.json
├── vite.config.ts
└── tsconfig.json
```

---

## 🧪 Testes Locais

Para testar o site localmente antes de fazer deploy:

```bash
# Modo desenvolvimento
pnpm dev

# Modo produção (simular)
pnpm build
pnpm preview
```

---

## 🔒 Segurança

✅ O site usa HTTPS (garantido pela maioria das plataformas de hosting)
✅ Certificado SSL automático (Vercel, Netlify, GitHub Pages)
✅ Sem dados sensíveis armazenados localmente
✅ Links para Mercado Livre são seguros

---

## 📊 Analytics (Opcional)

O site já está configurado para Google Analytics. Para ativar:

1. Crie uma conta em https://analytics.google.com
2. Configure um novo Property
3. Adicione o ID ao arquivo `.env`:
```
VITE_ANALYTICS_WEBSITE_ID=seu-id-aqui
```

---

## 🆘 Troubleshooting

### Problema: "npm ERR! code ERESOLVE"
**Solução:**
```bash
npm install --legacy-peer-deps
```

### Problema: Build falha com erro de TypeScript
**Solução:**
```bash
pnpm check
# Corrija os erros reportados
```

### Problema: Imagens não carregam após deploy
**Solução:** Verifique se as imagens estão em `client/public/images/` e referenciadas corretamente no código.

---

## 📞 Suporte

Para dúvidas sobre o projeto:
- WhatsApp: 11 91674-5566
- Email: seu-email@exemplo.com

---

## 📄 Licença

Este projeto é fornecido como está para uso pessoal e comercial.

---

**Última atualização:** 05/12/2025
