# Mercado Online Livre Jr

Um site de e-commerce elegante e responsivo para venda de produtos variados (perfumes árabes, ferramentas, shampoos, saúde) com integração ao Mercado Livre.

## Características

✨ **Design Premium**
- Design Luxo Minimalista com tipografia Playfair Display + Open Sans
- Paleta sofisticada em ouro, preto e branco
- Totalmente responsivo (mobile, tablet, desktop)

🛍️ **Funcionalidades**
- Seção de produtos com 4 categorias
- Depoimentos de clientes
- Formulário de sugestão de produtos
- Botão WhatsApp flutuante para contato rápido
- Links diretos para Mercado Livre
- Páginas de Privacidade e Termos de Uso

🚀 **Tecnologias**
- React 19
- TypeScript
- Tailwind CSS 4
- Vite
- Wouter (roteamento)

## Instalação Rápida

### 1. Clonar o repositório
```bash
git clone <seu-repositorio-url>
cd mercado_online_jr
```

### 2. Instalar dependências
```bash
pnpm install
# ou
npm install
```

### 3. Executar em desenvolvimento
```bash
pnpm dev
# ou
npm run dev
```

O site estará disponível em `http://localhost:5173`

### 4. Build para produção
```bash
pnpm build
# ou
npm run build
```

Os arquivos compilados estarão em `dist/`

## Estrutura do Projeto

```
mercado_online_jr/
├── client/
│   ├── public/
│   │   └── images/          # Imagens do site
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Home.tsx     # Página principal
│   │   │   ├── Privacidade.tsx
│   │   │   ├── Termos.tsx
│   │   │   └── NotFound.tsx
│   │   ├── components/      # Componentes reutilizáveis
│   │   ├── App.tsx          # Rotas
│   │   ├── index.css        # Estilos globais
│   │   └── main.tsx
│   └── index.html
├── package.json
├── vite.config.ts
├── tsconfig.json
└── INSTRUCOES_MIGRACAO.md   # Guia de deploy
```

## Customizações

### Alterar Número do WhatsApp
Edite `client/src/pages/Home.tsx`:
```javascript
href="https://wa.me/5511916745566"
```

### Adicionar Novos Produtos
Edite `client/src/pages/Home.tsx` e adicione ao array `products`:
```javascript
{
  id: 5,
  name: "Novo Produto",
  category: "Categoria",
  image: "/images/novo-produto.jpg",
  link: "https://seu-link-aqui",
}
```

### Alterar Cores
Edite `client/src/index.css` e modifique as variáveis CSS:
```css
--primary: #d4af37;
--secondary: #1a1a1a;
```

## Deploy

Veja o arquivo `INSTRUCOES_MIGRACAO.md` para instruções detalhadas de deploy em:
- Vercel (recomendado)
- Netlify
- GitHub Pages
- Hospedagem compartilhada

## Segurança

- ✓ HTTPS automático
- ✓ Certificado SSL
- ✓ Sem dados sensíveis armazenados
- ✓ Links seguros para Mercado Livre

## Suporte

Para dúvidas ou sugestões:
- WhatsApp: 11 91674-5566

## Licença

Este projeto é fornecido como está para uso pessoal e comercial.

---

**Desenvolvido com elegância e sofisticação.**
