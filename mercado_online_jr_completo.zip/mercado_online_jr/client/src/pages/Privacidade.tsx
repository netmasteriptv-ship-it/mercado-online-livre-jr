import { ShoppingBag } from "lucide-react";

export default function Privacidade() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-8 h-8 text-amber-600" />
            <h1 className="text-2xl font-bold text-gray-900">
              Mercado Online Livre Jr
            </h1>
          </div>
          <nav className="hidden md:flex gap-8">
            <a
              href="/"
              className="text-gray-700 font-semibold hover:text-amber-600 transition-colors"
            >
              Início
            </a>
          </nav>
        </div>
      </header>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h1 className="text-4xl font-bold text-gray-900 mb-8">
          Política de Privacidade
        </h1>

        <div className="prose prose-lg max-w-none text-gray-700 space-y-6">
          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              1. Introdução
            </h2>
            <p>
              A Mercado Online Livre Jr ("nós", "nosso" ou "a Empresa") opera o
              site mercadoonlinelivrjr.com. Esta página informa você sobre nossas
              políticas de coleta, uso e divulgação de dados pessoais quando você
              usa nosso site.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              2. Coleta de Dados
            </h2>
            <p>
              Coletamos dados pessoais que você nos fornece voluntariamente,
              como:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Nome e email (através do formulário de contato)</li>
              <li>Informações sobre produtos de interesse</li>
              <li>Dados de navegação e uso do site (via cookies)</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              3. Uso dos Dados
            </h2>
            <p>Utilizamos os dados coletados para:</p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Responder às suas solicitações e sugestões</li>
              <li>Melhorar a experiência do usuário no site</li>
              <li>Enviar comunicações sobre produtos e serviços</li>
              <li>Análise de tráfego e otimização do site</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              4. Segurança dos Dados
            </h2>
            <p>
              Implementamos medidas de segurança técnicas e organizacionais para
              proteger seus dados pessoais contra acesso não autorizado,
              alteração, divulgação ou destruição. O site utiliza certificado
              SSL (HTTPS) para criptografar dados em trânsito.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              5. Cookies
            </h2>
            <p>
              Nosso site utiliza cookies para melhorar a experiência do usuário.
              Você pode controlar o uso de cookies através das configurações do
              seu navegador.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              6. Links Externos
            </h2>
            <p>
              Nosso site contém links para o Mercado Livre. Não somos
              responsáveis pela política de privacidade de sites terceiros. Ao
              clicar em links externos, você sai de nosso site.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              7. Direitos do Usuário
            </h2>
            <p>
              Você tem direito a acessar, corrigir ou solicitar a exclusão de
              seus dados pessoais. Para exercer esses direitos, entre em contato
              conosco através do WhatsApp ou formulário de contato.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              8. Alterações à Política
            </h2>
            <p>
              Podemos atualizar esta Política de Privacidade periodicamente. As
              alterações entram em vigor imediatamente após a publicação no site.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              9. Contato
            </h2>
            <p>
              Se você tiver dúvidas sobre esta Política de Privacidade, entre em
              contato conosco através do WhatsApp: 11 91674-5566
            </p>
          </section>

          <div className="mt-12 p-6 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600">
              Última atualização: {new Date().toLocaleDateString("pt-BR")}
            </p>
          </div>
        </div>

        <div className="mt-12">
          <a
            href="/"
            className="inline-block bg-amber-600 hover:bg-amber-700 text-white font-bold py-3 px-6 rounded-full transition-colors"
          >
            Voltar ao Início
          </a>
        </div>
      </div>
    </div>
  );
}
