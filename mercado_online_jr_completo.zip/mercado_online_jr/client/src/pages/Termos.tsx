import { ShoppingBag } from "lucide-react";

export default function Termos() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-8 h-8 text-amber-600" />
            <h1 className="text-2xl font-bold text-gray-900">
              Mercado Online Livre Jr
            </h1>
          </div>
          <nav className="hidden md:flex gap-8">
            <a
              href="/"
              className="text-gray-700 font-semibold hover:text-amber-600 transition-colors"
            >
              Início
            </a>
          </nav>
        </div>
      </header>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h1 className="text-4xl font-bold text-gray-900 mb-8">
          Termos de Uso
        </h1>

        <div className="prose prose-lg max-w-none text-gray-700 space-y-6">
          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              1. Aceitação dos Termos
            </h2>
            <p>
              Ao acessar e usar o site Mercado Online Livre Jr, você aceita
              estar vinculado por estes Termos de Uso. Se você não concorda com
              qualquer parte destes termos, não use o site.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              2. Uso Licenciado
            </h2>
            <p>
              O conteúdo deste site é fornecido "como está" para seu uso
              pessoal e não comercial. Você não pode modificar, copiar,
              distribuir, transmitir, exibir, executar, reproduzir, publicar,
              licenciar, criar trabalhos derivados ou vender qualquer
              informação, software ou serviços obtidos do site.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              3. Isenção de Responsabilidade
            </h2>
            <p>
              O site funciona como um agregador de produtos do Mercado Livre.
              Não somos responsáveis pela qualidade, entrega ou qualquer
              problema relacionado aos produtos vendidos através da plataforma
              do Mercado Livre. Todas as transações são realizadas diretamente
              com o Mercado Livre.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              4. Links Externos
            </h2>
            <p>
              Nosso site contém links para o Mercado Livre. Não somos
              responsáveis pelo conteúdo, precisão ou práticas de sites
              terceiros. O acesso a links externos é por sua conta e risco.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              5. Limitação de Responsabilidade
            </h2>
            <p>
              Em nenhum caso a Mercado Online Livre Jr será responsável por
              danos diretos, indiretos, incidentais, especiais ou
              consequenciais, incluindo perda de lucros, mesmo que tenha sido
              avisada da possibilidade de tais danos.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              6. Modificações do Site
            </h2>
            <p>
              Reservamos o direito de modificar ou descontinuar o site a
              qualquer momento, com ou sem aviso prévio. Não seremos
              responsáveis por qualquer modificação ou descontinuação.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              7. Conduta do Usuário
            </h2>
            <p>Você concorda em não:</p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>
                Usar o site para qualquer propósito ilegal ou não autorizado
              </li>
              <li>
                Transmitir qualquer conteúdo abusivo, obsceno ou ofensivo
              </li>
              <li>Interferir com o funcionamento do site</li>
              <li>Coletar ou rastrear informações pessoais de outros usuários</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              8. Propriedade Intelectual
            </h2>
            <p>
              Todo o conteúdo do site, incluindo texto, gráficos, logos e
              imagens, é propriedade da Mercado Online Livre Jr ou seus
              fornecedores de conteúdo e é protegido por leis de direitos
              autorais.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              9. Indenização
            </h2>
            <p>
              Você concorda em indenizar e manter a Mercado Online Livre Jr
              inofensa de qualquer reclamação, dano ou custo decorrente de seu
              uso do site ou violação destes Termos de Uso.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              10. Lei Aplicável
            </h2>
            <p>
              Estes Termos de Uso são regidos pelas leis da República
              Federativa do Brasil, sem considerar seus conflitos de
              disposições legais.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              11. Contato
            </h2>
            <p>
              Se você tiver dúvidas sobre estes Termos de Uso, entre em contato
              conosco através do WhatsApp: 11 91674-5566
            </p>
          </section>

          <div className="mt-12 p-6 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600">
              Última atualização: {new Date().toLocaleDateString("pt-BR")}
            </p>
          </div>
        </div>

        <div className="mt-12">
          <a
            href="/"
            className="inline-block bg-amber-600 hover:bg-amber-700 text-white font-bold py-3 px-6 rounded-full transition-colors"
          >
            Voltar ao Início
          </a>
        </div>
      </div>
    </div>
  );
}
