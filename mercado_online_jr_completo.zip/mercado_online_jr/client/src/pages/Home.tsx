import { Button } from "@/components/ui/button";
import { MessageCircle, ShoppingBag, Star, MapPin, Phone } from "lucide-react";
import { useState } from "react";

/**
 * Design: Luxo Minimalista com Tipografia Serif
 * - Playfair Display para títulos (elegância e sofisticação)
 * - Open Sans para corpo (legibilidade moderna)
 * - Paleta: Ouro (#d4af37), Preto (#1a1a1a), Branco
 * - Espaçamento amplo para elegância
 */

interface Product {
  id: number;
  name: string;
  category: string;
  image: string;
  link: string;
}

interface Testimonial {
  id: number;
  name: string;
  text: string;
  rating: number;
}

const MERCADO_LIVRE_PROFILE = "https://www.mercadolivre.com.br/social/ernanidepaulamoreirajunior";

const products: Product[] = [
  {
    id: 1,
    name: "Perfume Árabe Luxo",
    category: "Perfumaria",
    image: "/images/perfume-hero.jpg",
    link: MERCADO_LIVRE_PROFILE,
  },
  {
    id: 2,
    name: "Ferramenta Multiuso",
    category: "Ferramentas",
    image: "/images/tools-showcase.jpg",
    link: MERCADO_LIVRE_PROFILE,
  },
  {
    id: 3,
    name: "Shampoo de Beleza",
    category: "Beleza",
    image: "/images/beauty-products.jpg",
    link: MERCADO_LIVRE_PROFILE,
  },
  {
    id: 4,
    name: "Produtos de Saúde",
    category: "Saúde",
    image: "/images/beauty-products.jpg",
    link: MERCADO_LIVRE_PROFILE,
  },
];

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Maria Silva",
    text: "Excelente qualidade de produtos! Entrega rápida e atendimento muito bom. Recomendo!",
    rating: 5,
  },
  {
    id: 2,
    name: "João Santos",
    text: "Produtos originais e com preços competitivos. Voltarei a comprar com certeza!",
    rating: 5,
  },
  {
    id: 3,
    name: "Ana Costa",
    text: "Ótima experiência de compra. O atendimento via WhatsApp foi muito rápido e eficiente.",
    rating: 5,
  },
];

export default function Home() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    product: "",
  });

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Formulário enviado:", formData);
    setFormData({ name: "", email: "", product: "" });
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-8 h-8 text-amber-600" />
            <h1 className="text-2xl font-bold text-gray-900">
              Mercado Online Livre Jr
            </h1>
          </div>
          <nav className="hidden md:flex gap-8">
            <a
              href="#inicio"
              className="text-gray-700 font-semibold hover:text-amber-600 transition-colors"
            >
              Início
            </a>
            <a
              href="#produtos"
              className="text-gray-700 font-semibold hover:text-amber-600 transition-colors"
            >
              Produtos
            </a>
            <a
              href="#sobre"
              className="text-gray-700 font-semibold hover:text-amber-600 transition-colors"
            >
              Sobre
            </a>
            <a
              href="#contato"
              className="text-gray-700 font-semibold hover:text-amber-600 transition-colors"
            >
              Contato
            </a>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section id="inicio" className="relative h-96 md:h-[500px] overflow-hidden bg-gradient-to-b from-blue-100 to-blue-50">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: "url('/images/hero-online-shop.jpg')" }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-blue-50/40"></div>
        </div>
        <div className="relative h-full flex flex-col items-center justify-center text-center px-4">
          <div className="mb-6 animate-bounce">
            <img
              src="/images/logo-hero.png"
              alt="Online Shop"
              className="h-24 md:h-32 object-contain drop-shadow-lg"
            />
          </div>
          <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-4 drop-shadow-lg">
            Mercado Online Livre Jr
          </h2>
          <p className="text-base md:text-lg text-gray-700 mb-8 max-w-2xl drop-shadow-md font-semibold">
            Perfumes árabes, ferramentas, shampoos, saúde e muito mais! Compre
            com segurança e rapidez.
          </p>
          <Button
            size="lg"
            className="bg-amber-600 hover:bg-amber-700 text-white px-8 py-3 text-lg font-semibold rounded-full shadow-lg transition-all hover:shadow-xl"
            onClick={() =>
              document
                .getElementById("produtos")
                ?.scrollIntoView({ behavior: "smooth" })
            }
          >
            Veja os Produtos
          </Button>
        </div>
      </section>

      {/* Products Section */}
      <section id="produtos" className="py-20 md:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Nossos Produtos Destaque
            </h2>
            <div className="w-20 h-1 bg-amber-600 mx-auto"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {products.map((product) => (
              <div
                key={product.id}
                className="group bg-white rounded-lg overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300 hover:-translate-y-2"
              >
                <div className="relative h-48 overflow-hidden bg-gray-100">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-6">
                  <div className="text-xs font-semibold text-amber-600 uppercase tracking-wider mb-2">
                    {product.category}
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">
                    {product.name}
                  </h3>
                  <div className="flex items-center gap-1 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className="w-4 h-4 fill-amber-600 text-amber-600"
                      />
                    ))}
                  </div>
                  <a
                    href={product.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block w-full bg-amber-600 hover:bg-amber-700 text-white font-bold py-3 px-4 rounded-full text-center transition-colors"
                  >
                    Comprar
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="sobre" className="py-20 md:py-32 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              O Que Nossos Clientes Dizem
            </h2>
            <div className="w-20 h-1 bg-amber-600 mx-auto"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial) => (
              <div
                key={testimonial.id}
                className="bg-white rounded-lg shadow-md p-8 hover:shadow-lg transition-shadow"
              >
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star
                      key={i}
                      className="w-5 h-5 fill-amber-600 text-amber-600"
                    />
                  ))}
                </div>
                <p className="text-gray-700 mb-6 italic">"{testimonial.text}"</p>
                <div className="font-bold text-gray-900">{testimonial.name}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contato" className="py-20 md:py-32 bg-white">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Quer um Produto Específico?
            </h2>
            <p className="text-lg text-gray-600">
              Envie sua sugestão e nós incluiremos na nossa loja.
            </p>
          </div>

          <form
            onSubmit={handleSubmit}
            className="bg-gray-50 rounded-lg shadow-lg p-8 space-y-6"
          >
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Nome
              </label>
              <input
                type="text"
                name="name"
                placeholder="Seu nome"
                value={formData.name}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Email (Opcional)
              </label>
              <input
                type="email"
                name="email"
                placeholder="Seu email"
                value={formData.email}
                onChange={handleInputChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Produto Desejado
              </label>
              <textarea
                name="product"
                placeholder="Descreva o produto que você gostaria de encontrar"
                rows={4}
                value={formData.product}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-600 focus:border-transparent resize-none"
              ></textarea>
            </div>
            <button
              type="submit"
              className="w-full bg-amber-600 hover:bg-amber-700 text-white font-bold py-3 px-6 rounded-full transition-colors"
            >
              Enviar
            </button>
          </form>

          <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-gray-50 rounded-lg p-8 text-center">
              <Phone className="w-12 h-12 text-amber-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">WhatsApp</h3>
              <p className="text-gray-600 mb-4">
                Estamos à disposição para ajudar!
              </p>
              <a
                href="https://wa.me/5511916745566"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-6 rounded-full transition-colors"
              >
                Fale Conosco
              </a>
            </div>
            <div className="bg-gray-50 rounded-lg p-8 text-center">
              <MapPin className="w-12 h-12 text-amber-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">Localização</h3>
              <p className="text-gray-600">
                Atendemos em todo o Brasil com segurança e rapidez.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* WhatsApp Floating Button */}
      <a
        href="https://wa.me/5511916745566"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-40 bg-green-500 hover:bg-green-600 text-white rounded-full p-4 shadow-lg transition-all hover:shadow-xl hover:scale-110 flex items-center gap-2"
        title="Fale pelo WhatsApp"
      >
        <MessageCircle className="w-6 h-6" />
        <span className="hidden sm:inline font-semibold">WhatsApp</span>
      </a>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="text-white font-bold mb-4">Sobre</h3>
              <ul className="space-y-2">
                <li>
                  <a href="#sobre" className="hover:text-white transition-colors">
                    Sobre Nós
                  </a>
                </li>
                <li>
                  <a href="#produtos" className="hover:text-white transition-colors">
                    Produtos
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-bold mb-4">Suporte</h3>
              <ul className="space-y-2">
                <li>
                  <a href="#contato" className="hover:text-white transition-colors">
                    Contato
                  </a>
                </li>
                <li>
                  <a href="/privacidade" className="hover:text-white transition-colors">
                    Política de Privacidade
                  </a>
                </li>
                <li>
                  <a href="/termos" className="hover:text-white transition-colors">
                    Termos de Uso
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-bold mb-4">Redes Sociais</h3>
              <ul className="space-y-2">
                <li>
                  <a
                    href="https://wa.me/5511916745566"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-white transition-colors"
                  >
                    WhatsApp
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-bold mb-4">Segurança</h3>
              <ul className="space-y-2">
                <li className="text-sm">
                  🔒 Certificado SSL Ativo
                </li>
                <li className="text-sm">
                  ✓ Site Seguro
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center">
            <p className="text-sm">
              &copy; 2024 Mercado Online Livre Jr. Todos os direitos reservados.
            </p>
            <p className="text-xs mt-2">
              Desenvolvido com elegância e sofisticação.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
